# PRJ-01 — Surveillance multicapteur d'une électropompe

Projet du portfolio « Maintenance intelligente & Stratégies 4.0 » (ENSIT, 5ᵉ année).

**Question :** sur une électropompe, quel groupe de capteurs (vibration, électrique, hydraulique, thermique) détecte quel mode de défaillance, avec quel délai et combien de fausses alarmes ? Comment traduire ces mesures en indice de détection D de l'AMDEC ?

**Données :** Skoltech Anomaly Benchmark (SKAB) — banc réel de circulation d'eau, 8 capteurs à 1 Hz, 34 expériences de défaut (7 modes) et 1 enregistrement sain. Licence GPL-3.0. https://github.com/waico/SKAB

## Résultats principaux (T², référence locale, 34 expériences)

| Groupe | Détection stricte | Délai médian | Fausses alarmes / h |
|---|---|---|---|
| Hydraulique (débit, pression) | 79 % | 34 s | 3,1 |
| Vibration | 26 % | 15 s | 10,0 |
| Électrique (courant, tension) | 15 % | 190 s | 0,0 |
| Tous les capteurs | 68 % | 14 s | 8,7 |
| Vibration + hydraulique *(a posteriori)* | 82 % | 25 s | 7,5 |

*Détection stricte* : la première alarme après la période de référence tombe pendant le défaut.
Tous les chiffres sont dans `resultats/resume_chiffres.md`, généré par le code. Le rapport complet est la fiche PRJ-01 du portfolio.

## Installation et exécution

Prérequis : Python 3.10 ou plus récent, et git.

```
python telecharger_donnees.py        # clone SKAB dans donnees/SKAB (18 Mo)
pip install -r requirements.txt
python run_all.py                    # environ 1 minute
```

Avec Docker :

```
docker build -t prj01 .
docker run --rm -v "${PWD}/resultats:/projet/resultats" prj01
```

## Organisation

```
telecharger_donnees.py   téléchargement des données SKAB
run_all.py               lance expériences, figures et résumé
src/
  config.py              tous les réglages (capteurs, groupes, référence, seuil, persistance)
  donnees.py             chargement, découpage référence / test, contrôle qualité
  detecteurs.py          indicateurs causaux, T² de Hotelling, Isolation Forest, règle d'alarme
  metriques.py           métriques point par point (SKAB) et par événement (maintenance)
  experiences.py         E1 groupes × méthodes ; E2 référence globale ; E3 sensibilité ; E4 protocole SKAB
  figures.py             figures du rapport
  resume.py              resultats/resume_chiffres.md
resultats/
  tableaux/              CSV et JSON de tous les résultats
  figures/               PNG du rapport
```

## Choix méthodologiques

- **Apprentissage sur l'état sain uniquement** : 75 % de la référence locale pour le modèle, 25 % pour le seuil (quantile 99,5 %).
- **Indicateurs causaux** (passé uniquement) : écart entre la moyenne des 10 dernières secondes et la ligne de base des 120 secondes précédentes, plus l'écart-type sur 10 s.
- **Alarme** après 10 s consécutives au-dessus du seuil.
- **Réglages choisis sur les 16 expériences « valve1 »** (jeu de développement) ; résultats également donnés sur les 18 autres.
- Le groupe vibration + hydraulique a été ajouté après lecture des premiers résultats : c'est une hypothèse à confirmer sur de nouvelles données.

## Limites

Défauts provoqués sur un seul banc ; 1 ou 2 expériences pour certains modes ; signaux efficaces à 1 Hz, donc sans analyse spectrale du courant ; trous d'enregistrement non traités ; pas d'estimation de durée de vie résiduelle (pas de dégradation jusqu'à la panne dans les données).

## Licence des données

SKAB : © Skoltech, GPL-3.0. Citation : I. D. Katser et V. O. Kozitsin, « Skoltech Anomaly Benchmark (SKAB) », Kaggle, 2020, doi : 10.34740/KAGGLE/DSV/1693952. La photo du banc (`fig_banc_skab.png`) provient du dépôt SKAB.

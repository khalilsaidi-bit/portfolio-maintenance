"""Lance tout le projet : expériences, figures, résumé chiffré.

Usage :  python run_all.py
Prérequis : données SKAB dans donnees/SKAB (voir telecharger_donnees.py).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

import config as C  # noqa: E402

if not C.DONNEES.exists():
    sys.exit(f"Données introuvables dans {C.DONNEES}. Lancez d'abord : python telecharger_donnees.py")

import experiences, figures, resume  # noqa: E402

experiences.main()
figures.main()
resume.main()
print("Terminé. Résultats dans", C.RESULTATS)

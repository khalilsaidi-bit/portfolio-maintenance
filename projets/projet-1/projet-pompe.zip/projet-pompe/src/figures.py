"""Figures du rapport, générées à partir des tableaux de resultats/tableaux/."""
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

import config as C
from donnees import charger_experiences
from detecteurs import indicateurs, seuil_et_alarmes, T2

VERT, AMBRE, BLEU = "#007f56", "#b06a00", "#2f6cc4"
ENCRE, GRIS, GRILLE, ZONE = "#17232b", "#566670", "#d3dbdf", "#f2cbc6"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": GRIS, "axes.labelcolor": ENCRE,
    "xtick.color": GRIS, "ytick.color": GRIS, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRILLE, "grid.linewidth": 0.6, "axes.axisbelow": True,
    "figure.dpi": 150, "savefig.bbox": "tight", "savefig.facecolor": "white",
})
ORDRE_GROUPES = ["Vibration", "Électrique", "Hydraulique", "Thermique", "Vibration + électrique", "Tous les capteurs", "Vibration + hydraulique"]
COURT = {"Accelerometer1RMS": "Vibration 1", "Accelerometer2RMS": "Vibration 2", "Current": "Courant",
         "Voltage": "Tension", "Pressure": "Pression", "Volume Flow RateRMS": "Débit",
         "Temperature": "T° moteur", "Thermocouple": "T° fluide"}


def sauver(fig, nom):
    C.FIGURES.mkdir(parents=True, exist_ok=True)
    fig.savefig(C.FIGURES / nom)
    plt.close(fig)


def fig_signaux(exps):
    choix = [("other/6.csv", "Balourd du rotor"), ("other/12.csv", "Cavitation"), ("valve1/0.csv", "Obstruction à l'aspiration")]
    capt = [("Accelerometer1RMS", "Vibration 1 (g)"), ("Volume Flow RateRMS", "Débit (L/min)"), ("Current", "Courant (A)")]
    fig, ax = plt.subplots(3, 3, figsize=(10, 6), sharex="col")
    for j, (f, titre) in enumerate(choix):
        e = next(x for x in exps if x.fichier == f)
        t = np.arange(len(e.df))
        for i, (c, lab) in enumerate(capt):
            a = ax[i, j]
            y = e.df[c].values
            a.axvspan(e.debut_defaut, e.fin_defaut, color=ZONE, lw=0, label="défaut étiqueté")
            a.axvline(e.fin_ref, color=GRIS, lw=0.8, ls="--")
            a.plot(t, y, color=[BLEU, VERT, AMBRE][i], lw=0.8)
            if j == 0:
                a.set_ylabel(lab)
            if i == 0:
                a.set_title(f"{titre}\n({f})", fontsize=9, color=ENCRE)
            if i == 2:
                a.set_xlabel("temps (s)")
    ax[0, 0].text(5, ax[0, 0].get_ylim()[1], "référence", va="top", fontsize=7, color=GRIS)
    fig.suptitle("Signaux bruts de trois expériences : zone rose = défaut étiqueté, tirets = fin de la référence",
                 fontsize=9, color=GRIS, y=1.0)
    fig.tight_layout()
    sauver(fig, "fig_signaux.png")


def fig_signatures():
    s = pd.read_csv(C.TABLEAUX / "signatures_par_mode.csv", index_col=0)
    s = s[list(COURT)].rename(columns=COURT)
    z = np.sign(s.values) * np.log10(1 + np.abs(s.values))
    cmap = LinearSegmentedColormap.from_list("div", [BLEU, "#eef1f3", AMBRE])
    lim = np.abs(z).max()
    fig, ax = plt.subplots(figsize=(9, 3.8))
    ax.grid(False)
    ax.imshow(z, cmap=cmap, vmin=-lim, vmax=lim, aspect="auto")
    ax.set_xticks(range(s.shape[1]), s.columns, rotation=0)
    ax.set_yticks(range(s.shape[0]), s.index)
    for i in range(s.shape[0]):
        for j in range(s.shape[1]):
            v = s.values[i, j]
            txt = f"{v:+.0f}" if abs(v) >= 10 else f"{v:+.1f}"
            ax.text(j, i, txt.replace(".", ","), ha="center", va="center", fontsize=8,
                    color="white" if abs(z[i, j]) > 0.75 * lim else ENCRE, fontweight="bold" if abs(v) >= 2 else "normal")
    ax.tick_params(length=0)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.set_title("Effet standardisé du défaut sur chaque capteur (médiane par mode ; |effet| ≥ 2 en gras)",
                 fontsize=9, color=GRIS, loc="left")
    sauver(fig, "fig_signatures.png")


def fig_groupes():
    s = pd.read_csv(C.TABLEAUX / "synthese_groupes.csv")
    s = s[(s.methode == "T²") & (s.reference == "locale") & (s.perimetre == "toutes")].set_index("groupe").reindex(ORDRE_GROUPES)
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.4))
    y = np.arange(len(s))
    ax[0].barh(y, 100 * s["taux_detection_stricte"], color=VERT, height=0.6)
    ax[0].set_xlim(0, 100)
    ax[0].set_xlabel("détection stricte (% des 34 expériences)")
    ax[1].barh(y, s["fa_par_heure"], color=AMBRE, height=0.6)
    ax[1].set_xlabel("fausses alarmes par heure de fonctionnement sain")
    for a, col, fmt in [(ax[0], "taux_detection_stricte", lambda v: f"{100*v:.0f} %"), (ax[1], "fa_par_heure", lambda v: f"{v:.1f}".replace(".", ","))]:
        a.set_yticks(y, s.index)
        a.invert_yaxis()
        a.grid(axis="y", visible=False)
        for k, v in enumerate(s[col]):
            a.text(a.get_xlim()[1] * 0.01 + (100 * v if col == "taux_detection_stricte" else v), k, " " + fmt(v), va="center", fontsize=8, color=ENCRE)
    ax[1].set_yticklabels([])
    ax[1].set_xlim(0, max(s["fa_par_heure"]) * 1.25)
    fig.suptitle("Détecteur T², référence locale : performance par groupe de capteurs", fontsize=9, color=GRIS, x=0.02, ha="left")
    fig.tight_layout()
    sauver(fig, "fig_groupes.png")


def fig_detectabilite():
    m = pd.read_csv(C.TABLEAUX / "detectabilite_mode_groupe.csv")
    t = m.pivot(index="mode", columns="groupe", values="taux_detection_stricte").reindex(index=C.ORDRE_MODES, columns=ORDRE_GROUPES)
    D = m.pivot(index="mode", columns="groupe", values="indice_D").reindex(index=C.ORDRE_MODES, columns=ORDRE_GROUPES)
    n = m.groupby("mode")["n_experiences"].first().reindex(C.ORDRE_MODES)
    cmap = LinearSegmentedColormap.from_list("seq", ["#f4f7f6", "#9fd0bb", VERT])
    fig, ax = plt.subplots(figsize=(10, 4.2))
    ax.grid(False)
    ax.imshow(t.values, cmap=cmap, vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(range(t.shape[1]), [g.replace(" + ", "\n+ ") for g in t.columns])
    ax.set_yticks(range(t.shape[0]), [f"{i} (n={n[i]})" for i in t.index])
    for i in range(t.shape[0]):
        for j in range(t.shape[1]):
            v = t.values[i, j]
            ax.text(j, i, f"{100*v:.0f} %\nD = {int(D.values[i, j])}", ha="center", va="center", fontsize=8,
                    color="white" if v > 0.7 else ENCRE)
    ax.tick_params(length=0)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.set_title("Matrice de détectabilité : détection stricte par mode et par groupe de capteurs, et indice D proposé pour l'AMDEC",
                 fontsize=9, color=GRIS, loc="left")
    sauver(fig, "fig_detectabilite.png")


def fig_compromis():
    s = pd.read_csv(C.TABLEAUX / "sensibilite_reglages.csv")
    s = s[s["quantile"] == 0.995]
    fig, ax = plt.subplots(figsize=(7.5, 4))
    for typ, col, lab, mk in [("niveau", AMBRE, "indicateurs de niveau", "s"), ("ecart", VERT, "indicateurs d'écart à la ligne de base", "o")]:
        d = s[s.indicateurs == typ].sort_values("persistance_s")
        ax.plot(d["fa_par_heure"], 100 * d["taux_detection_stricte"], color=col, lw=2, marker=mk, ms=7, label=lab)
        for _, r in d.iterrows():
            off = (8, 6) if typ == "ecart" else (6, -14)
            ax.annotate(f"{int(r.persistance_s)} s", (r.fa_par_heure, 100 * r.taux_detection_stricte),
                        textcoords="offset points", xytext=off, fontsize=8, color=col)
    ax.set_xlabel("fausses alarmes par heure (moins = mieux)")
    ax.set_ylabel("détection stricte (%)")
    ax.set_xlim(0, None); ax.set_ylim(0, 100)
    ax.legend(frameon=False, loc="lower right")
    ax.set_title("Compromis détection / fausses alarmes selon la persistance de l'alarme (tous capteurs, T², quantile 99,5 %)", fontsize=9, color=GRIS, loc="left")
    sauver(fig, "fig_compromis.png")


def fig_exemple(exps):
    e = next(x for x in exps if x.fichier == "valve2/0.csv")
    feats = indicateurs(e.df, C.GROUPES["Tous les capteurs"]).values
    score, seuil, alarme = seuil_et_alarmes(T2, feats, e.fin_ref)
    t = np.arange(len(score))
    fig, ax = plt.subplots(figsize=(9, 3.2))
    ax.axvspan(e.debut_defaut, e.fin_defaut, color=ZONE, lw=0)
    ax.axvspan(0, e.fin_ref, color="#eef1f3", lw=0)
    ax.plot(t, score, color=BLEU, lw=1)
    ax.axhline(seuil, color=AMBRE, ls="--", lw=1.2)
    ax.set_yscale("log")
    bas = score.min() * 0.55
    ax.fill_between(t, bas, bas * 1.35, where=alarme, color=VERT, lw=0, step="mid")
    ax.text(5, bas * 1.5, "alarmes", fontsize=8, color=VERT)
    ax.set_ylim(bas * 0.9, None)
    ax.set_xlabel("temps (s)"); ax.set_ylabel("score T² (échelle log)")
    ax.text(e.fin_ref / 2, seuil * 1.4, "référence (état sain)", ha="center", fontsize=8, color=GRIS)
    ax.text(e.debut_defaut + 5, score.max(), "défaut étiqueté", va="top", fontsize=8, color=ENCRE)
    ax.text(len(t) - 5, seuil * 1.15, "seuil", ha="right", fontsize=8, color=AMBRE)
    ax.set_title("Obstruction au refoulement (valve2/0) : score, seuil et alarmes (bande verte en bas)", fontsize=9, color=GRIS, loc="left")
    sauver(fig, "fig_exemple_score.png")


def main():
    exps = charger_experiences()
    fig_signaux(exps)
    fig_signatures()
    fig_groupes()
    fig_detectabilite()
    fig_compromis()
    fig_exemple(exps)
    shutil.copy(C.DONNEES.parent / "docs" / "pictures" / "testbed.png", C.FIGURES / "fig_banc_skab.png")
    print("Figures enregistrées dans", C.FIGURES)


if __name__ == "__main__":
    main()

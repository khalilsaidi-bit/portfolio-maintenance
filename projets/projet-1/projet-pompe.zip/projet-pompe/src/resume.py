"""Écrit resultats/resume_chiffres.md : tous les chiffres cités dans le rapport, issus des tableaux."""
import json
import pandas as pd
import config as C


def pct(x):
    return f"{100 * x:.0f} %"


def main():
    s = pd.read_csv(C.TABLEAUX / "synthese_groupes.csv")
    m = pd.read_csv(C.TABLEAUX / "detectabilite_mode_groupe.csv")
    sens = pd.read_csv(C.TABLEAUX / "sensibilite_reglages.csv")
    qc = pd.read_csv(C.TABLEAUX / "controle_qualite.csv")
    skab = json.load(open(C.TABLEAUX / "controle_protocole_skab.json"))
    L = ["# Chiffres clés (générés automatiquement par src/resume.py)", ""]

    L += ["## Données", f"- Expériences avec défaut : {len(qc) - 1} ; fichier sain : 1 ({int(qc.iloc[0].points)} points)",
          f"- Valeurs manquantes : {int(qc.valeurs_manquantes.sum())}",
          f"- Fichiers avec trous d'échantillonnage > 5 s : {int((qc.trous_sup_5s > 0).sum())} (plus grand : {qc.plus_grand_trou_s.max():.0f} s)",
          f"- Références tronquées (défaut avant 400 s) : {', '.join(qc[qc.ref_tronquee == True].fichier)}", ""]

    L += ["## Synthèse par groupe (T² sauf mention)", "",
          "| Groupe | Méthode | Référence | Périmètre | Détection stricte | Détection | Délai médian (s) | FA/h | F1 | FAR | MAR |",
          "|---|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in s.iterrows():
        L.append(f"| {r.groupe} | {r.methode} | {r.reference} | {r.perimetre} | {pct(r.taux_detection_stricte)} | {pct(r.taux_detection)} | "
                 f"{r.delai_median_s:.0f} | {r.fa_par_heure:.1f} | {r.F1:.2f} | {r.FAR:.2f} | {r.MAR:.2f} |")
    L += ["", "## Détectabilité (T², référence locale)", "",
          "| Mode | Groupe | n | Détection stricte | Délai médian (s) | D |", "|---|---|---|---|---|---|"]
    for _, r in m.iterrows():
        L.append(f"| {r['mode']} | {r.groupe} | {r.n_experiences} | {pct(r.taux_detection_stricte)} | "
                 f"{'' if pd.isna(r.delai_median_s) else f'{r.delai_median_s:.0f}'} | {r.indice_D} |")
    L += ["", "## Sensibilité (tous capteurs, T²)", "", sens.round(3).to_markdown(index=False) if hasattr(sens, "to_markdown") else sens.round(3).to_string(index=False)]
    L += ["", "## Contrôle avec le protocole SKAB (400 premiers points, valeurs brutes, T², quantile 99 %)",
          f"- F1 = {skab['F1']:.3f} ; FAR = {skab['FAR']:.3f} ; MAR = {skab['MAR']:.3f}"]
    (C.RESULTATS / "resume_chiffres.md").write_text("\n".join(L), encoding="utf-8")
    print("Résumé écrit :", C.RESULTATS / "resume_chiffres.md")


if __name__ == "__main__":
    main()

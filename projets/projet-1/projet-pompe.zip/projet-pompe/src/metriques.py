"""Métriques ponctuelles (comme le benchmark SKAB) et métriques par événement (vision maintenance)."""
import numpy as np


def ponctuelles(y, alarme):
    y = np.asarray(y).astype(bool); p = np.asarray(alarme).astype(bool)
    tp = int((y & p).sum()); fp = int((~y & p).sum()); fn = int((y & ~p).sum()); tn = int((~y & ~p).sum())
    return {"TP": tp, "FP": fp, "FN": fn, "TN": tn}


def scores(c):
    tp, fp, fn, tn = c["TP"], c["FP"], c["FN"], c["TN"]
    prec = tp / (tp + fp) if tp + fp else 0.0
    rap = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * prec * rap / (prec + rap) if prec + rap else 0.0
    far = fp / (fp + tn) if fp + tn else 0.0   # taux de fausses alarmes (points sains signalés)
    mar = fn / (fn + tp) if fn + tp else 0.0   # taux d'alarmes manquées (points anormaux non signalés)
    return {"F1": f1, "Précision": prec, "Rappel": rap, "FAR": far, "MAR": mar}


def evenement(alarme, fin_ref, debut, fin):
    """Détection du premier défaut : détecté ? délai (s) ? fausse alarme avant le défaut ?"""
    a = np.asarray(alarme).astype(bool)
    dans = np.flatnonzero(a[debut:fin])
    detecte = dans.size > 0
    delai = float(dans[0]) if detecte else np.nan
    avant = a[fin_ref:debut]
    # nombre d'épisodes d'alarme (fronts montants) sur la partie saine avant le défaut
    episodes = int(np.sum(np.diff(np.r_[0, avant.astype(int)]) == 1))
    # détection stricte : la toute première alarme après la référence tombe pendant le défaut
    apres = np.flatnonzero(a[fin_ref:]) + fin_ref
    strict = bool(apres.size and debut <= apres[0] < fin)
    return {"detecte": detecte, "detection_stricte": strict, "delai_s": delai, "fausse_alarme_avant": bool(avant.any()),
            "episodes_fa": episodes, "duree_saine_s": int(debut - fin_ref)}

"""Toutes les expériences du projet. Produit les tableaux CSV dans resultats/tableaux/."""
import json
import numpy as np
import pandas as pd

import config as C
from donnees import charger_experiences, charger_sans_anomalie, controle_qualite
from detecteurs import indicateurs, seuil_et_alarmes, T2, IForet
from metriques import ponctuelles, scores, evenement

METHODES = {"T²": T2, "Isolation Forest": IForet}


def indice_D(taux_strict, delai_med):
    """Convention du projet : traduire la détectabilité mesurée en indice D d'AMDEC (1 = très bien détecté).

    taux_strict : part des expériences où la première alarme tombe pendant le défaut.
    """
    if taux_strict >= 0.9 and not np.isnan(delai_med) and delai_med <= 60:
        return 1
    if taux_strict >= 0.7:
        return 2
    if taux_strict >= 0.4:
        return 3
    return 4


def lancer_config(exps, groupe, methode, ref_globale=None):
    capteurs = C.GROUPES[groupe]
    lignes = []
    X_glob = None
    if ref_globale is not None:
        X_glob = indicateurs(ref_globale, capteurs).values[C.LIGNE_DE_BASE:]
    for e in exps:
        feats = indicateurs(e.df, capteurs).values
        score, seuil, alarme = seuil_et_alarmes(METHODES[methode], feats, e.fin_ref, X_glob)
        y = e.df["anomaly"].values
        c = ponctuelles(y[e.fin_ref:], alarme[e.fin_ref:])
        ev = evenement(alarme, e.fin_ref, e.debut_defaut, e.fin_defaut)
        lignes.append({"fichier": e.fichier, "mode": e.mode, "groupe": groupe, "methode": methode,
                       "reference": "globale" if ref_globale is not None else "locale",
                       "jeu": "développement" if e.fichier.startswith(C.JEU_DEV) else "test",
                       **ev, **c})
    return pd.DataFrame(lignes)


def resumer(d: pd.DataFrame) -> dict:
    cum = {k: int(d[k].sum()) for k in ("TP", "FP", "FN", "TN")}
    return {**cum, **scores(cum),
            "n_exp": len(d),
            "taux_detection": d["detecte"].mean(),
            "taux_detection_stricte": d["detection_stricte"].mean(),
            "delai_median_s": d.loc[d.detecte, "delai_s"].median(),
            "part_exp_avec_fa": d["fausse_alarme_avant"].mean(),
            "fa_par_heure": d["episodes_fa"].sum() / (d["duree_saine_s"].sum() / 3600)}


def signatures(exps):
    """Effet standardisé de chaque défaut sur chaque capteur.

    effet = (moyenne pendant le défaut − moyenne des 60 s précédant le défaut) / écart-type de la référence.
    La comparaison avec la minute qui précède limite l'effet des dérives lentes (température).
    """
    lignes = []
    for e in exps:
        cols = list(C.CAPTEURS)
        ref = e.df[cols].iloc[:e.fin_ref]
        avant = e.df[cols].iloc[max(0, e.debut_defaut - 60):e.debut_defaut]
        pendant = e.df[cols].iloc[e.debut_defaut:e.fin_defaut]
        eff = (pendant.mean() - avant.mean()) / (ref.std() + 1e-9)
        lignes.append({"fichier": e.fichier, "mode": e.mode, **eff.to_dict()})
    return pd.DataFrame(lignes)


def main():
    C.TABLEAUX.mkdir(parents=True, exist_ok=True)
    exps = charger_experiences()
    sain = charger_sans_anomalie()

    controle_qualite(exps, sain).to_csv(C.TABLEAUX / "controle_qualite.csv", index=False)

    sig = signatures(exps)
    sig.to_csv(C.TABLEAUX / "signatures_par_experience.csv", index=False)
    sig.groupby("mode")[list(C.CAPTEURS)].median().reindex(C.ORDRE_MODES).to_csv(C.TABLEAUX / "signatures_par_mode.csv")

    # E1 : groupes de capteurs × méthodes, référence locale ; E2 : référence globale (T²)
    tous = []
    for groupe in C.GROUPES:
        for methode in METHODES:
            tous.append(lancer_config(exps, groupe, methode))
        tous.append(lancer_config(exps, groupe, "T²", ref_globale=sain))
    par_exp = pd.concat(tous, ignore_index=True)
    par_exp.to_csv(C.TABLEAUX / "resultats_par_experience.csv", index=False)

    synth = []
    for (g, m, r), d in par_exp.groupby(["groupe", "methode", "reference"], sort=False):
        synth.append({"groupe": g, "methode": m, "reference": r, "perimetre": "toutes", **resumer(d)})
        synth.append({"groupe": g, "methode": m, "reference": r, "perimetre": "test (hors développement)",
                      **resumer(d[d.jeu == "test"])})
    pd.DataFrame(synth).to_csv(C.TABLEAUX / "synthese_groupes.csv", index=False)

    # Matrice de détectabilité mode × groupe (T², référence locale) et indice D
    loc = par_exp[(par_exp.methode == "T²") & (par_exp.reference == "locale")]
    lignes = []
    for (mode, groupe), d in loc.groupby(["mode", "groupe"]):
        ts = d["detection_stricte"].mean()
        dm = d.loc[d.detection_stricte, "delai_s"].median()
        lignes.append({"mode": mode, "groupe": groupe, "n_experiences": len(d),
                       "taux_detection": d["detecte"].mean(), "taux_detection_stricte": ts,
                       "delai_median_s": dm, "indice_D": indice_D(ts, dm)})
    pd.DataFrame(lignes).to_csv(C.TABLEAUX / "detectabilite_mode_groupe.csv", index=False)

    # E3 : sensibilité aux réglages (tous capteurs, T², référence locale), sur toutes les expériences
    base = (C.TYPE_INDICATEURS, C.PERSISTANCE, C.QUANTILE_SEUIL)
    sens = []
    for typ in ("niveau", "ecart"):
        for pers in (1, 5, 10, 20):
            for q in (0.99, 0.995, 1.0):
                C.TYPE_INDICATEURS, C.PERSISTANCE, C.QUANTILE_SEUIL = typ, pers, q
                r = resumer(lancer_config(exps, "Tous les capteurs", "T²"))
                sens.append({"indicateurs": typ, "persistance_s": pers, "quantile": q,
                             **{k: r[k] for k in ("F1", "FAR", "MAR", "taux_detection_stricte", "fa_par_heure")}})
    C.TYPE_INDICATEURS, C.PERSISTANCE, C.QUANTILE_SEUIL = base
    pd.DataFrame(sens).to_csv(C.TABLEAUX / "sensibilite_reglages.csv", index=False)

    # E4 : contrôle de cohérence avec le protocole du benchmark SKAB
    # (400 premiers points pour l'apprentissage, valeurs brutes des 8 capteurs, T², seuil au quantile 99 %)
    cum = {"TP": 0, "FP": 0, "FN": 0, "TN": 0}
    for e in exps:
        X = e.df[list(C.CAPTEURS)].values.astype(float)
        m = T2().fit(X[:400])
        a = m.score(X) > np.quantile(m.score(X[:400]), 0.99)
        c = ponctuelles(e.df["anomaly"].values[400:], a[400:])
        for k in cum:
            cum[k] += c[k]
    with open(C.TABLEAUX / "controle_protocole_skab.json", "w") as f:
        json.dump({**cum, **scores(cum)}, f, indent=2, ensure_ascii=False)
    print("Expériences terminées :", len(exps), "fichiers")


if __name__ == "__main__":
    main()

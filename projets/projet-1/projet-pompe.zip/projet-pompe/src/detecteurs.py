"""Indicateurs glissants et détecteurs d'anomalies entraînés sur l'état sain uniquement."""
import numpy as np
import pandas as pd
from sklearn.covariance import LedoitWolf
from sklearn.ensemble import IsolationForest

import config as C
from config import PART_APPRENTISSAGE, GRAINE


def indicateurs(df: pd.DataFrame, capteurs) -> pd.DataFrame:
    """Indicateurs causaux (passé uniquement) pour chaque capteur.

    - écart : moyenne des FENETRE dernières secondes − ligne de base (moyenne des LIGNE_DE_BASE secondes
      qui précèdent). Il réagit à un changement brusque mais pas à une dérive lente (température).
    - écart-type des FENETRE dernières secondes : sensible aux fluctuations (cavitation, balourd).
    """
    x = df[capteurs].astype(float)
    moy = x.rolling(C.FENETRE, min_periods=1).mean()
    if C.TYPE_INDICATEURS == "ecart":
        base = x.rolling(C.LIGNE_DE_BASE, min_periods=1).mean().shift(C.FENETRE).bfill()
        moy = moy - base
    s = x.rolling(C.FENETRE, min_periods=2).std().fillna(0.0).add_suffix("|ect")
    return pd.concat([moy.add_suffix("|moy"), s], axis=1)


class T2:
    """Statistique T² de Hotelling (distance de Mahalanobis) avec covariance régularisée (Ledoit-Wolf)."""
    nom = "T² de Hotelling"

    def fit(self, X):
        self.mu = X.mean(axis=0)
        self.sd = X.std(axis=0) + 1e-9
        Z = (X - self.mu) / self.sd
        self.cov = LedoitWolf().fit(Z)
        return self

    def score(self, X):
        Z = (X - self.mu) / self.sd
        return self.cov.mahalanobis(Z)


class IForet:
    """Isolation Forest : plus le score est élevé, plus le point est isolé (anormal)."""
    nom = "Isolation Forest"

    def fit(self, X):
        self.mu = X.mean(axis=0)
        self.sd = X.std(axis=0) + 1e-9
        self.m = IsolationForest(n_estimators=200, random_state=GRAINE).fit((X - self.mu) / self.sd)
        return self

    def score(self, X):
        return -self.m.score_samples((X - self.mu) / self.sd)


def seuil_et_alarmes(modele_cls, feats: np.ndarray, fin_ref: int, X_ajust=None):
    """Ajuste le modèle, fixe le seuil sur la partie calibration, renvoie score, seuil et alarmes.

    - X_ajust fourni : modèle ajusté sur ces données (référence globale), seuil sur la référence locale.
    - sinon : 75 % de la référence locale pour ajuster, 25 % pour le seuil.
    """
    n_app = int(fin_ref * PART_APPRENTISSAGE)
    if X_ajust is None:
        modele = modele_cls().fit(feats[:n_app])
        calib = feats[n_app:fin_ref]
    else:
        modele = modele_cls().fit(X_ajust)
        calib = X_ajust[int(len(X_ajust) * PART_APPRENTISSAGE):]
    score = modele.score(feats)
    seuil = np.quantile(modele.score(calib), C.QUANTILE_SEUIL)
    depasse = score > seuil
    # persistance : alarme quand les PERSISTANCE dernières valeurs dépassent toutes le seuil
    run = pd.Series(depasse.astype(int)).rolling(C.PERSISTANCE, min_periods=C.PERSISTANCE).sum().fillna(0).values
    alarme = run >= C.PERSISTANCE
    return score, seuil, alarme

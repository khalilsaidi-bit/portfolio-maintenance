"""Paramètres du projet PRJ-01. Tous les choix méthodologiques sont regroupés ici."""
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
DONNEES = RACINE / "donnees" / "SKAB" / "data"
RESULTATS = RACINE / "resultats"
FIGURES = RESULTATS / "figures"
TABLEAUX = RESULTATS / "tableaux"

# Capteurs du banc SKAB (noms des colonnes) et libellés français
CAPTEURS = {
    "Accelerometer1RMS": "Vibration 1 (g RMS)",
    "Accelerometer2RMS": "Vibration 2 (g RMS)",
    "Current": "Courant moteur (A)",
    "Voltage": "Tension moteur (V)",
    "Pressure": "Pression refoulement (bar)",
    "Volume Flow RateRMS": "Débit (L/min)",
    "Temperature": "Température moteur (°C)",
    "Thermocouple": "Température fluide (°C)",
}

# Groupes de capteurs comparés (question centrale du projet)
GROUPES = {
    "Vibration": ["Accelerometer1RMS", "Accelerometer2RMS"],
    "Électrique": ["Current", "Voltage"],
    "Hydraulique": ["Pressure", "Volume Flow RateRMS"],
    "Thermique": ["Temperature", "Thermocouple"],
    "Vibration + électrique": ["Accelerometer1RMS", "Accelerometer2RMS", "Current", "Voltage"],
    "Tous les capteurs": list(CAPTEURS),
    # Ajoutée après lecture des premiers résultats (hypothèse a posteriori, signalée comme telle)
    "Vibration + hydraulique": ["Accelerometer1RMS", "Accelerometer2RMS", "Pressure", "Volume Flow RateRMS"],
}

# Correspondance expérience SKAB -> mode de défaillance (d'après data/README.md de SKAB)
def mode_de(fichier: str) -> str:
    dossier, nom = fichier.split("/")
    n = int(nom.split(".")[0])
    if dossier == "valve1":
        return "Obstruction à l'aspiration"
    if dossier == "valve2":
        return "Obstruction au refoulement"
    if n in (1, 2, 3, 4):
        return "Fuite / ajout de fluide"
    if n in (5, 6, 7, 8, 9):
        return "Balourd du rotor"
    if n in (10, 11):
        return "Hausse du niveau d'eau"
    if n in (12, 13):
        return "Cavitation"
    if n == 14:
        return "Fluide trop chaud"
    raise ValueError(fichier)

ORDRE_MODES = [
    "Obstruction à l'aspiration", "Obstruction au refoulement", "Fuite / ajout de fluide",
    "Balourd du rotor", "Hausse du niveau d'eau", "Cavitation", "Fluide trop chaud",
]

# Fenêtre de référence (état sain) au début de chaque expérience
N_REF_MAX = 400          # nombre maximal de points (1 point = 1 s)
MARGE_AVANT_DEFAUT = 10  # la référence s'arrête au moins 10 s avant la première anomalie étiquetée
PART_APPRENTISSAGE = 0.75  # 75 % de la référence pour ajuster le modèle, 25 % pour fixer le seuil

# Indicateurs calculés de façon causale (passé uniquement)
FENETRE = 10             # fenêtre courte (s) : moyenne et écart-type récents
LIGNE_DE_BASE = 120      # fenêtre longue (s) : ligne de base, décalée de FENETRE pour ne pas inclure le récent
TYPE_INDICATEURS = "ecart"  # "ecart" : moyenne récente − ligne de base ; "niveau" : moyenne récente brute

# Règle d'alarme
QUANTILE_SEUIL = 0.995   # seuil = quantile 99,5 % du score sur la partie « calibration » de la référence
PERSISTANCE = 10         # alarme si le score dépasse le seuil pendant 10 s consécutives

GRAINE = 0

# Jeu de développement : seules ces expériences ont servi à choisir les réglages ci-dessus
JEU_DEV = "valve1"

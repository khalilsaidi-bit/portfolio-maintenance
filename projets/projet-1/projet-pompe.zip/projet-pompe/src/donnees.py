"""Chargement des expériences SKAB, découpage référence / test, contrôle qualité."""
from dataclasses import dataclass
import numpy as np
import pandas as pd

from config import DONNEES, CAPTEURS, N_REF_MAX, MARGE_AVANT_DEFAUT, mode_de


@dataclass
class Experience:
    fichier: str            # ex. "valve1/3.csv"
    mode: str
    df: pd.DataFrame        # signaux + colonnes anomaly / changepoint
    fin_ref: int            # indice de fin (exclu) de la fenêtre de référence
    debut_defaut: int       # indice du premier point anomal
    fin_defaut: int         # indice (exclu) de fin du premier segment anomal


def lire_csv(chemin) -> pd.DataFrame:
    df = pd.read_csv(chemin, sep=";", index_col="datetime", parse_dates=True)
    return df.sort_index()


def segments(anomalie: np.ndarray):
    a = np.asarray(anomalie).astype(int)
    bords = np.flatnonzero(np.diff(np.r_[0, a, 0]))
    return list(zip(bords[::2], bords[1::2]))


def charger_experiences():
    exps = []
    for chemin in sorted(DONNEES.glob("*/*.csv")):
        if chemin.parent.name == "anomaly-free":
            continue
        fichier = f"{chemin.parent.name}/{chemin.name}"
        df = lire_csv(chemin)
        segs = segments(df["anomaly"].values)
        d0, f0 = segs[0]
        fin_ref = int(min(N_REF_MAX, d0 - MARGE_AVANT_DEFAUT))
        exps.append(Experience(fichier, mode_de(fichier), df, fin_ref, int(d0), int(f0)))
    return exps


def charger_sans_anomalie() -> pd.DataFrame:
    return lire_csv(DONNEES / "anomaly-free" / "anomaly-free.csv")


def controle_qualite(exps, sain: pd.DataFrame) -> pd.DataFrame:
    """Une ligne par fichier : durée, trous d'échantillonnage, valeurs manquantes, segments."""
    lignes = []
    for nom, df in [("anomaly-free/anomaly-free.csv", sain)] + [(e.fichier, e.df) for e in exps]:
        dt = df.index.to_series().diff().dt.total_seconds().dropna()
        segs = segments(df["anomaly"].values) if "anomaly" in df else []
        e = next((x for x in exps if x.fichier == nom), None)
        lignes.append({
            "fichier": nom,
            "mode": e.mode if e else "État sain (référence globale)",
            "date": df.index[0].date().isoformat(),
            "points": len(df),
            "pas_median_s": float(dt.median()),
            "trous_sup_5s": int((dt > 5).sum()),
            "plus_grand_trou_s": float(dt.max()),
            "valeurs_manquantes": int(df[list(CAPTEURS)].isna().sum().sum()),
            "segments_anomalie": len(segs),
            "points_anomalie": int(df["anomaly"].sum()) if "anomaly" in df else 0,
            "debut_defaut_s": e.debut_defaut if e else None,
            "ref_points": e.fin_ref if e else None,
            "ref_tronquee": bool(e and e.fin_ref < N_REF_MAX),
        })
    return pd.DataFrame(lignes)

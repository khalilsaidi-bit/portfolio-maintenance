"""Télécharge le jeu de données SKAB (Skoltech Anomaly Benchmark) dans donnees/SKAB.

Source officielle : https://github.com/waico/SKAB  (licence GPL-3.0)
Nécessite git. Sans git : télécharger le zip du dépôt depuis GitHub et le décompresser dans donnees/SKAB.
"""
import subprocess
import sys
from pathlib import Path

cible = Path(__file__).resolve().parent / "donnees" / "SKAB"
if (cible / "data").exists():
    print("Données déjà présentes :", cible)
    sys.exit(0)
cible.parent.mkdir(parents=True, exist_ok=True)
subprocess.run(["git", "clone", "--depth", "1", "https://github.com/waico/SKAB.git", str(cible)], check=True)
print("Données téléchargées dans", cible)

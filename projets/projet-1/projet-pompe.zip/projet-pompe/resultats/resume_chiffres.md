# Chiffres clés (générés automatiquement par src/resume.py)

## Données
- Expériences avec défaut : 34 ; fichier sain : 1 (9405 points)
- Valeurs manquantes : 0
- Fichiers avec trous d'échantillonnage > 5 s : 6 (plus grand : 247 s)
- Références tronquées (défaut avant 400 s) : other/2.csv

## Synthèse par groupe (T² sauf mention)

| Groupe | Méthode | Référence | Périmètre | Détection stricte | Détection | Délai médian (s) | FA/h | F1 | FAR | MAR |
|---|---|---|---|---|---|---|---|---|---|---|
| Vibration | T² | locale | toutes | 26 % | 53 % | 15 | 10.0 | 0.29 | 0.10 | 0.82 |
| Vibration | T² | locale | test (hors développement) | 39 % | 78 % | 12 | 14.3 | 0.42 | 0.19 | 0.69 |
| Vibration | Isolation Forest | locale | toutes | 21 % | 44 % | 15 | 8.7 | 0.19 | 0.05 | 0.89 |
| Vibration | Isolation Forest | locale | test (hors développement) | 39 % | 72 % | 15 | 11.9 | 0.32 | 0.10 | 0.80 |
| Vibration | T² | globale | toutes | 24 % | 24 % | 12 | 0.0 | 0.13 | 0.04 | 0.93 |
| Vibration | T² | globale | test (hors développement) | 44 % | 44 % | 12 | 0.0 | 0.23 | 0.08 | 0.86 |
| Électrique | T² | locale | toutes | 15 % | 15 % | 190 | 0.0 | 0.00 | 0.00 | 1.00 |
| Électrique | T² | locale | test (hors développement) | 17 % | 17 % | 120 | 0.0 | 0.01 | 0.00 | 1.00 |
| Électrique | Isolation Forest | locale | toutes | 3 % | 3 % | 145 | 0.0 | 0.00 | 0.00 | 1.00 |
| Électrique | Isolation Forest | locale | test (hors développement) | 0 % | 0 % | nan | 0.0 | 0.00 | 0.00 | 1.00 |
| Électrique | T² | globale | toutes | 18 % | 24 % | 136 | 1.9 | 0.01 | 0.00 | 1.00 |
| Électrique | T² | globale | test (hors développement) | 6 % | 6 % | 95 | 1.2 | 0.00 | 0.00 | 1.00 |
| Hydraulique | T² | locale | toutes | 79 % | 94 % | 34 | 3.1 | 0.39 | 0.13 | 0.73 |
| Hydraulique | T² | locale | test (hors développement) | 72 % | 89 % | 34 | 3.6 | 0.34 | 0.10 | 0.78 |
| Hydraulique | Isolation Forest | locale | toutes | 41 % | 50 % | 57 | 3.1 | 0.11 | 0.03 | 0.94 |
| Hydraulique | Isolation Forest | locale | test (hors développement) | 39 % | 50 % | 70 | 3.6 | 0.09 | 0.03 | 0.95 |
| Hydraulique | T² | globale | toutes | 50 % | 50 % | 66 | 0.0 | 0.18 | 0.04 | 0.90 |
| Hydraulique | T² | globale | test (hors développement) | 50 % | 50 % | 67 | 0.0 | 0.17 | 0.05 | 0.90 |
| Thermique | T² | locale | toutes | 24 % | 62 % | 44 | 13.1 | 0.24 | 0.13 | 0.84 |
| Thermique | T² | locale | test (hors développement) | 22 % | 56 % | 37 | 14.3 | 0.27 | 0.18 | 0.82 |
| Thermique | Isolation Forest | locale | toutes | 26 % | 44 % | 114 | 11.2 | 0.06 | 0.02 | 0.97 |
| Thermique | Isolation Forest | locale | test (hors développement) | 33 % | 56 % | 132 | 15.5 | 0.09 | 0.04 | 0.95 |
| Thermique | T² | globale | toutes | 18 % | 18 % | 63 | 1.2 | 0.06 | 0.00 | 0.97 |
| Thermique | T² | globale | test (hors développement) | 17 % | 17 % | 31 | 0.0 | 0.10 | 0.00 | 0.95 |
| Vibration + électrique | T² | locale | toutes | 41 % | 59 % | 20 | 6.9 | 0.26 | 0.09 | 0.84 |
| Vibration + électrique | T² | locale | test (hors développement) | 56 % | 78 % | 13 | 10.7 | 0.40 | 0.17 | 0.72 |
| Vibration + électrique | Isolation Forest | locale | toutes | 32 % | 41 % | 18 | 3.1 | 0.12 | 0.03 | 0.94 |
| Vibration + électrique | Isolation Forest | locale | test (hors développement) | 44 % | 56 % | 18 | 4.8 | 0.20 | 0.05 | 0.89 |
| Vibration + électrique | T² | globale | toutes | 24 % | 24 % | 12 | 0.0 | 0.13 | 0.04 | 0.93 |
| Vibration + électrique | T² | globale | test (hors développement) | 44 % | 44 % | 12 | 0.0 | 0.23 | 0.08 | 0.86 |
| Tous les capteurs | T² | locale | toutes | 68 % | 97 % | 14 | 8.7 | 0.51 | 0.23 | 0.59 |
| Tous les capteurs | T² | locale | test (hors développement) | 72 % | 100 % | 14 | 7.2 | 0.55 | 0.25 | 0.54 |
| Tous les capteurs | Isolation Forest | locale | toutes | 50 % | 59 % | 52 | 2.5 | 0.14 | 0.03 | 0.92 |
| Tous les capteurs | Isolation Forest | locale | test (hors développement) | 56 % | 72 % | 67 | 4.8 | 0.21 | 0.05 | 0.88 |
| Tous les capteurs | T² | globale | toutes | 32 % | 32 % | 12 | 0.0 | 0.21 | 0.06 | 0.88 |
| Tous les capteurs | T² | globale | test (hors développement) | 56 % | 56 % | 12 | 0.0 | 0.35 | 0.12 | 0.77 |
| Vibration + hydraulique | T² | locale | toutes | 82 % | 97 % | 25 | 7.5 | 0.49 | 0.20 | 0.62 |
| Vibration + hydraulique | T² | locale | test (hors développement) | 78 % | 100 % | 17 | 10.7 | 0.56 | 0.23 | 0.54 |
| Vibration + hydraulique | Isolation Forest | locale | toutes | 47 % | 59 % | 26 | 3.7 | 0.22 | 0.04 | 0.87 |
| Vibration + hydraulique | Isolation Forest | locale | test (hors développement) | 50 % | 72 % | 13 | 7.2 | 0.34 | 0.08 | 0.78 |
| Vibration + hydraulique | T² | globale | toutes | 26 % | 26 % | 12 | 0.0 | 0.17 | 0.06 | 0.90 |
| Vibration + hydraulique | T² | globale | test (hors développement) | 44 % | 44 % | 11 | 0.0 | 0.29 | 0.12 | 0.81 |

## Détectabilité (T², référence locale)

| Mode | Groupe | n | Détection stricte | Délai médian (s) | D |
|---|---|---|---|---|---|
| Balourd du rotor | Hydraulique | 5 | 40 % | 102 | 3 |
| Balourd du rotor | Thermique | 5 | 40 % | 264 | 3 |
| Balourd du rotor | Tous les capteurs | 5 | 80 % | 10 | 2 |
| Balourd du rotor | Vibration | 5 | 60 % | 9 | 3 |
| Balourd du rotor | Vibration + hydraulique | 5 | 80 % | 10 | 2 |
| Balourd du rotor | Vibration + électrique | 5 | 80 % | 8 | 2 |
| Balourd du rotor | Électrique | 5 | 40 % | 155 | 3 |
| Cavitation | Hydraulique | 2 | 100 % | 51 | 1 |
| Cavitation | Thermique | 2 | 0 % |  | 4 |
| Cavitation | Tous les capteurs | 2 | 100 % | 51 | 1 |
| Cavitation | Vibration | 2 | 50 % | 27 | 3 |
| Cavitation | Vibration + hydraulique | 2 | 100 % | 51 | 1 |
| Cavitation | Vibration + électrique | 2 | 100 % | 40 | 1 |
| Cavitation | Électrique | 2 | 0 % |  | 4 |
| Fluide trop chaud | Hydraulique | 1 | 100 % | 18 | 1 |
| Fluide trop chaud | Thermique | 1 | 0 % |  | 4 |
| Fluide trop chaud | Tous les capteurs | 1 | 100 % | 13 | 1 |
| Fluide trop chaud | Vibration | 1 | 100 % | 8 | 1 |
| Fluide trop chaud | Vibration + hydraulique | 1 | 100 % | 9 | 1 |
| Fluide trop chaud | Vibration + électrique | 1 | 100 % | 9 | 1 |
| Fluide trop chaud | Électrique | 1 | 0 % |  | 4 |
| Fuite / ajout de fluide | Hydraulique | 4 | 75 % | 27 | 2 |
| Fuite / ajout de fluide | Thermique | 4 | 25 % | 9 | 4 |
| Fuite / ajout de fluide | Tous les capteurs | 4 | 50 % | 16 | 3 |
| Fuite / ajout de fluide | Vibration | 4 | 25 % | 17 | 4 |
| Fuite / ajout de fluide | Vibration + hydraulique | 4 | 75 % | 19 | 2 |
| Fuite / ajout de fluide | Vibration + électrique | 4 | 25 % | 17 | 4 |
| Fuite / ajout de fluide | Électrique | 4 | 0 % |  | 4 |
| Hausse du niveau d'eau | Hydraulique | 2 | 50 % | 51 | 3 |
| Hausse du niveau d'eau | Thermique | 2 | 50 % | 32 | 3 |
| Hausse du niveau d'eau | Tous les capteurs | 2 | 100 % | 24 | 1 |
| Hausse du niveau d'eau | Vibration | 2 | 50 % | 13 | 3 |
| Hausse du niveau d'eau | Vibration + hydraulique | 2 | 50 % | 47 | 3 |
| Hausse du niveau d'eau | Vibration + électrique | 2 | 100 % | 40 | 1 |
| Hausse du niveau d'eau | Électrique | 2 | 0 % |  | 4 |
| Obstruction au refoulement | Hydraulique | 4 | 100 % | 34 | 1 |
| Obstruction au refoulement | Thermique | 4 | 0 % |  | 4 |
| Obstruction au refoulement | Tous les capteurs | 4 | 50 % | 34 | 3 |
| Obstruction au refoulement | Vibration | 4 | 0 % |  | 4 |
| Obstruction au refoulement | Vibration + hydraulique | 4 | 75 % | 27 | 2 |
| Obstruction au refoulement | Vibration + électrique | 4 | 0 % |  | 4 |
| Obstruction au refoulement | Électrique | 4 | 25 % | 70 | 4 |
| Obstruction à l'aspiration | Hydraulique | 16 | 88 % | 32 | 2 |
| Obstruction à l'aspiration | Thermique | 16 | 25 % | 139 | 4 |
| Obstruction à l'aspiration | Tous les capteurs | 16 | 62 % | 46 | 3 |
| Obstruction à l'aspiration | Vibration | 16 | 12 % | 130 | 4 |
| Obstruction à l'aspiration | Vibration + hydraulique | 16 | 88 % | 44 | 2 |
| Obstruction à l'aspiration | Vibration + électrique | 16 | 25 % | 88 | 4 |
| Obstruction à l'aspiration | Électrique | 16 | 12 % | 256 | 4 |

## Sensibilité (tous capteurs, T²)

| indicateurs   |   persistance_s |   quantile |    F1 |   FAR |   MAR |   taux_detection_stricte |   fa_par_heure |
|:--------------|----------------:|-----------:|------:|------:|------:|-------------------------:|---------------:|
| niveau        |               1 |      0.99  | 0.779 | 0.457 | 0.116 |                    0.206 |         85.343 |
| niveau        |               1 |      0.995 | 0.781 | 0.447 | 0.117 |                    0.235 |         82.852 |
| niveau        |               1 |      1     | 0.782 | 0.439 | 0.119 |                    0.235 |         85.966 |
| niveau        |               5 |      0.99  | 0.783 | 0.407 | 0.135 |                    0.294 |         35.508 |
| niveau        |               5 |      0.995 | 0.785 | 0.398 | 0.136 |                    0.324 |         31.147 |
| niveau        |               5 |      1     | 0.786 | 0.391 | 0.139 |                    0.382 |         29.901 |
| niveau        |              10 |      0.99  | 0.783 | 0.377 | 0.153 |                    0.412 |         20.557 |
| niveau        |              10 |      0.995 | 0.784 | 0.369 | 0.154 |                    0.5   |         18.688 |
| niveau        |              10 |      1     | 0.784 | 0.362 | 0.157 |                    0.588 |         18.688 |
| niveau        |              20 |      0.99  | 0.776 | 0.344 | 0.182 |                    0.618 |         11.213 |
| niveau        |              20 |      0.995 | 0.777 | 0.337 | 0.184 |                    0.618 |         10.59  |
| niveau        |              20 |      1     | 0.778 | 0.33  | 0.186 |                    0.588 |         11.836 |
| ecart         |               1 |      0.99  | 0.571 | 0.299 | 0.499 |                    0.353 |         52.95  |
| ecart         |               1 |      0.995 | 0.569 | 0.293 | 0.504 |                    0.353 |         47.967 |
| ecart         |               1 |      1     | 0.566 | 0.288 | 0.509 |                    0.412 |         38     |
| ecart         |               5 |      0.99  | 0.539 | 0.26  | 0.549 |                    0.559 |         19.311 |
| ecart         |               5 |      0.995 | 0.536 | 0.255 | 0.554 |                    0.559 |         18.065 |
| ecart         |               5 |      1     | 0.534 | 0.251 | 0.558 |                    0.559 |         18.065 |
| ecart         |              10 |      0.99  | 0.51  | 0.238 | 0.589 |                    0.676 |          9.344 |
| ecart         |              10 |      0.995 | 0.508 | 0.233 | 0.592 |                    0.676 |          8.721 |
| ecart         |              10 |      1     | 0.506 | 0.23  | 0.596 |                    0.676 |          8.098 |
| ecart         |              20 |      0.99  | 0.46  | 0.211 | 0.648 |                    0.676 |          5.607 |
| ecart         |              20 |      0.995 | 0.458 | 0.208 | 0.651 |                    0.735 |          4.361 |
| ecart         |              20 |      1     | 0.456 | 0.206 | 0.653 |                    0.735 |          4.361 |

## Contrôle avec le protocole SKAB (400 premiers points, valeurs brutes, T², quantile 99 %)
- F1 = 0.763 ; FAR = 0.485 ; MAR = 0.125